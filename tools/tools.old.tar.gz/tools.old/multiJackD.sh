#!/bin/bash

aplay -l


