#!/bin/bash
amidi -l
